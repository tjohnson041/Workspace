// Trevor Johnson 1/16/24
public class CH1_EX2 {

	public static void main(String[] args) {
		System.out.println( "'Ogres are like onions' from the moive Sherk said by Sherk and released in 2001" );

	}

}
