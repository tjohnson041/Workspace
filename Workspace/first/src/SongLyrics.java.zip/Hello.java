// Trevor 1/15/2024 Song lyrics
public class Hello {

	public static void main(String[] args) {
		System.out.println("My life like a movie, I do not do this often, yeah (yeah, ayy, ayy)\r\n"
				+ "Not do this often, I be swaggin' and saucin', yeah (ayy, ayy)\r\n"
				+ "My life like a movie, I do not do this often, yeah");

	}

}
